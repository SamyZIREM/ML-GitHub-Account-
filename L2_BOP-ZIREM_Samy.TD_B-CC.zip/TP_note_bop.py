import sys
sys.argv
def nb_parf(n):
a=int (sys.argv[1])
	for i in range (1,1+n):
	a=o
		for k in range (1,i):
			if i%k==0
			a+=k
		if a==i:
			print ("Le nombre est pafait")
		elif:
			print ("Le nombre n'est pas parfait")



